#ifndef _UIP_TYPE_
#define _UIP_TYPE_

/**
 * 8 bit datatype
 *
 * This typedef defines the 8-bit type used throughout uIP.
 *
 * \hideinitializer
 */
typedef unsigned char u8_t;
/*
#ifndef u8_t
#define	u8_t	unsigned char
#endif
*/
#ifndef BYTE
#define	BYTE	unsigned char
#endif
#ifndef BOOL
#define	BOOL	unsigned char
#endif

/**
 * 16 bit datatype
 *
 * This typedef defines the 16-bit type used throughout uIP.
 *
 * \hideinitializer
 */
typedef unsigned short u16_t; 
/*
#ifndef u16_t
#define	u16_t	unsigned short
#endif
*/
#ifndef WORD
#define	WORD	unsigned short
#endif

#endif /* _UIP_TYPE_ */

